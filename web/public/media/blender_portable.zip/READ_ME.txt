Blender 5.2 project. This portable copy uses 2K textures.
The full 4K project remains in the local repository at output/taichi_scene.blend.
All lighting, 432 animation frames, 24 bones and foot IK controls are preserved.
